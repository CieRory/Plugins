<?php

namespace DeliciousBrains\WPMDBTP\Cli;

class ThemePluginFilesCli {
    //Silence is golden.
}
