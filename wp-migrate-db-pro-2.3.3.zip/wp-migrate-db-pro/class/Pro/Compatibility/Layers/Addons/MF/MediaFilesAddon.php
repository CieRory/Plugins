<?php

namespace DeliciousBrains\WPMDBMF;

class MediaFilesAddon {
    //Silence is golden.
}
