<?php defined( 'ABSPATH' ) || exit; ?>
<div>
	<strong><?php _e( 'Improve Security', 'wp-migrate-db' ); ?></strong> &mdash;
	<?php printf( __( 'We have implemented a more secure method of secret key generation since your key was generated. We recommend you <a href="%s">visit the Settings tab</a> and reset your secret key.', 'wp-migrate-db' ), '#settings' ); ?>
</div>
